@echo off
chcp 65001 >nul
title Contract Manager - Local Server
cd /d "%~dp0"

echo ============================================================
echo    Contract Manager - Local Server / سرور محلی قراردادها
echo ============================================================
echo.

rem ---- 1) Find Python / یافتن پایتون ----
set "PYCMD="
python --version >nul 2>&1 && set "PYCMD=python"
if not defined PYCMD py -3 --version >nul 2>&1 && set "PYCMD=py -3"
if defined PYCMD goto :py_found

echo [ERROR] Python not found! / Python پیدا نشد!
echo Please install Python 3.10+ from python.org and run this file again.
echo لطفاً Python 3.10 یا جدیدتر را از python.org نصب کنید و دوباره این فایل را اجرا کنید.
echo Download: https://www.python.org/downloads/
echo.
pause
exit /b 1

:py_found
rem ---- 2) Create venv if missing / ساخت محیط مجازی در صورت نبود ----
if exist ".venv\Scripts\python.exe" goto :venv_ok
echo Creating virtual environment... / در حال ساخت محیط مجازی...
%PYCMD% -m venv .venv
if errorlevel 1 (
    echo [ERROR] Could not create venv. / ساخت محیط مجازی ناموفق بود.
    pause
    exit /b 1
)

:venv_ok
set "VENV_PY=.venv\Scripts\python.exe"
rem ---- 3) Install requirements on first run / نصب وابستگی‌ها فقط بار اول ----
if exist ".venv\.installed" goto :run
echo Installing requirements - first run needs internet... / نصب وابستگی‌ها - بار اول نیازمند اینترنت...
%VENV_PY% -m pip install -r requirements.txt --disable-pip-version-check -q
if errorlevel 1 (
    echo [ERROR] Installing dependencies failed. / نصب وابستگی‌ها ناموفق بود.
    echo Check your internet connection and run this file again.
    echo اتصال اینترنت را بررسی کنید و دوباره این فایل را اجرا کنید.
    pause
    exit /b 1
)
type nul > ".venv\.installed"

:run
rem ---- 4) Run server / اجرای سرور ----
echo Starting server... / در حال اجرای سرور...
echo.
%VENV_PY% run_server.py --open-browser
echo.
echo Server stopped. / سرور متوقف شد.
pause
