"""راه‌انداز سرور محلی — پارس آرگومان، چک پورت، باز کردن مرورگر پس از آماده شدن.

مثال‌ها:
    python run_server.py
    python run_server.py --port 8010 --no-browser
"""
import argparse
import socket
import sys
import threading
import time
import urllib.request
import webbrowser

from app.config import HOST, PORT

# پیام‌های کنسول بدون خطای انکودینگ
try:
    sys.stdout.reconfigure(errors="replace")
    sys.stderr.reconfigure(errors="replace")
except Exception:
    pass


def _parse_args():
    parser = argparse.ArgumentParser(description="سرور محلی سامانه مدیریت قراردادهای پیمانکاری")
    parser.add_argument("--host", default=HOST, help="آدرس bind (پیش‌فرض از config.json)")
    parser.add_argument("--port", type=int, default=PORT, help="پورت (پیش‌فرض از config.json)")
    parser.add_argument("--no-browser", action="store_true", help="باز نکردن خودکار مرورگر")
    parser.add_argument("--open-browser", action="store_true", help="باز کردن مرورگر (رفتار پیش‌فرض)")
    return parser.parse_args()


def port_in_use(host: str, port: int) -> bool:
    """بررسی اشغال بودن پورت با bind آزمایشی."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(1.5)
        try:
            sock.bind((host, port))
            return False
        except OSError:
            return True


def _open_browser_when_ready(port: int, url: str) -> None:
    """تا ۳۰ ثانیه هر ۰٫۵ ثانیه /api/health را پینگ می‌کند؛ بعد از موفقیت مرورگر باز می‌شود."""
    health_url = "http://127.0.0.1:{}/api/health".format(port)
    deadline = time.time() + 30
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(health_url, timeout=1.5) as resp:
                if resp.status == 200:
                    webbrowser.open(url)
                    return
        except Exception:
            time.sleep(0.5)


def main() -> int:
    args = _parse_args()
    host = args.host or "127.0.0.1"
    # میزبان آزمایش bind (برای 0.0.0.0/localhost روی لوکال تست می‌کنیم)
    bind_test_host = {"localhost": "127.0.0.1", "0.0.0.0": "127.0.0.1", "::": "127.0.0.1", "": "127.0.0.1"}.get(
        host, host
    )

    # چک پورت قبل از شروع — پیام واضح فارسی
    if port_in_use(bind_test_host, args.port):
        print(
            "پورت {n} اشغال است. احتمالاً سرور قبلاً در حال اجراست؛ "
            "مرورگر را روی http://127.0.0.1:{n} باز کنید.".format(n=args.port)
        )
        print("Port {n} is already in use. The server is probably running; open http://127.0.0.1:{n}".format(n=args.port))
        return 1

    # باز کردن مرورگر پس از آماده شدن سرور (ترد کمکی)
    open_browser = (not args.no_browser) or args.open_browser
    if open_browser:
        url = "http://127.0.0.1:{}/".format(args.port)
        threading.Thread(target=_open_browser_when_ready, args=(args.port, url), daemon=True).start()

    # ایمپورت app بعد از چک پورت (خطاهای import هم پشت پیام پورت پنهان نشوند)
    from app.main import app  # noqa: E402
    import uvicorn  # noqa: E402

    try:
        uvicorn.run(app, host=host, port=args.port, log_level="info")
    except KeyboardInterrupt:
        pass
    print("سرور متوقف شد.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
