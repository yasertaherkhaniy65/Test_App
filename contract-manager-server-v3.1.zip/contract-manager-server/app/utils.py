"""ابزارهای مشترک: نرمال‌سازی متن فارسی، اعتبارسنجی تاریخ شمسی، خطای استاندارد."""
import re
import time
import uuid
from typing import Optional

from fastapi import HTTPException

# ارقام فارسی و عربی → لاتین
_DIGIT_MAP = {
    "۰": "0", "۱": "1", "۲": "2", "۳": "3", "۴": "4",
    "۵": "5", "۶": "6", "۷": "7", "۸": "8", "۹": "9",
    "٠": "0", "١": "1", "٢": "2", "٣": "3", "٤": "4",
    "٥": "5", "٦": "6", "٧": "7", "٨": "8", "٩": "9",
}
_DIGIT_RE = re.compile("[۰-۹٠-٩]")

# الگوی تاریخ شمسی (سال چهاررقمی، ماه/روز یک یا دوردقمی)
_DATE_RE = re.compile(r"^([0-9]{4})[/\-.]([0-9]{1,2})[/\-.]([0-9]{1,2})$")


def to_latin_digits(s: str) -> str:
    """تبدیل ارقام فارسی/عربی به لاتین."""
    return _DIGIT_RE.sub(lambda m: _DIGIT_MAP[m.group(0)], s)


def norm_text(s: Optional[str]) -> str:
    """نرمال‌سازی متن فارسی برای یکتایی و جستجو:
    ارقام فارسی/عربی→لاتین، ي→ی، ك→ک، trim، فاصله‌های چندگانه→یکی، lowercase."""
    if s is None:
        return ""
    text = to_latin_digits(str(s))
    text = text.replace("ي", "ی").replace("ك", "ک")
    text = re.sub(r"\s+", " ", text.strip())
    return text.lower()


def _is_jalali_leap(year: int) -> bool:
    """الگوریتم استاندارد کبیسه جلالی بر اساس چرخه ۳۳ ساله."""
    return year % 33 in (1, 5, 9, 13, 17, 22, 26, 30)


def jalali_month_length(year: int, month: int) -> int:
    """طول ماه شمسی: ۱..۶ → ۳۱ روز، ۷..۱۱ → ۳۰ روز، اسفند ۲۹ یا ۳۰ (کبیسه)."""
    if month <= 6:
        return 31
    if month <= 11:
        return 30
    return 30 if _is_jalali_leap(year) else 29


def validate_jalali(value: Optional[str]) -> Optional[str]:
    """اعتبارسنجی تاریخ شمسی؛ در صورت اعتبار، رشته نرمال yyyy/mm/dd برمی‌گرداند.

    صفر پیش‌رو در خروجی تضمین می‌شود (مثال: 1404/05/03).
    """
    if value is None:
        return None
    text = to_latin_digits(str(value)).strip()
    match = _DATE_RE.match(text)
    if match is None:
        return None
    year, month, day = int(match.group(1)), int(match.group(2)), int(match.group(3))
    if not (1 <= month <= 12):
        return None
    if not (1 <= day <= jalali_month_length(year, month)):
        return None
    # بازه معقول سال برای جلوگیری از داده‌های بی‌معنی
    if not (1200 <= year <= 1600):
        return None
    return "{:04d}/{:02d}/{:02d}".format(year, month, day)


def fa_error(msg: str) -> HTTPException:
    """خطای استاندارد ۴۰۰ با پیام فارسی (پاسخ: {"detail": msg})."""
    return HTTPException(status_code=400, detail=msg)


def now_ms() -> int:
    """زمان جاری به میلی‌ثانیه (epoch ms)."""
    return int(time.time() * 1000)


def new_id() -> str:
    """شناسه یکتای رشته‌ای (uuid4) — هماهنگ با idهای IndexedDB کلاینت."""
    return str(uuid.uuid4())
