PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS schema_version (version INTEGER NOT NULL);

CREATE TABLE IF NOT EXISTS contractors (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  name_norm TEXT NOT NULL UNIQUE,
  type TEXT NOT NULL DEFAULT '',
  grade TEXT NOT NULL DEFAULT '',
  mobile TEXT NOT NULL DEFAULT '',
  address TEXT NOT NULL DEFAULT '',
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS deputies (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  name_norm TEXT NOT NULL UNIQUE,
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS contracts (
  id TEXT PRIMARY KEY,
  contract_number TEXT NOT NULL,
  contract_number_norm TEXT NOT NULL UNIQUE,
  date TEXT NOT NULL,
  title TEXT NOT NULL,
  contractor_id TEXT NOT NULL REFERENCES contractors(id) ON DELETE RESTRICT,
  deputy_id TEXT NOT NULL REFERENCES deputies(id) ON DELETE RESTRICT,
  duration_value INTEGER NOT NULL CHECK(duration_value >= 1 AND duration_value <= 1200),
  duration_unit TEXT NOT NULL DEFAULT 'ماه' CHECK(duration_unit IN ('ماه','روز','سال')),
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_contracts_contractor ON contracts(contractor_id);
CREATE INDEX IF NOT EXISTS idx_contracts_deputy ON contracts(deputy_id);
CREATE INDEX IF NOT EXISTS idx_contracts_date ON contracts(date);

CREATE TABLE IF NOT EXISTS settings (
  id TEXT PRIMARY KEY CHECK(id = 'app'),
  company_name TEXT NOT NULL DEFAULT '',
  logo TEXT NOT NULL DEFAULT '',
  theme TEXT NOT NULL DEFAULT 'light' CHECK(theme IN ('light','dark')),
  page_size INTEGER NOT NULL DEFAULT 10 CHECK(page_size IN (5,10,25,50)),
  notifications_enabled INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS backup_history (
  id TEXT PRIMARY KEY,
  file_name TEXT NOT NULL,
  date TEXT NOT NULL,
  size INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_backup_history_date ON backup_history(date);
