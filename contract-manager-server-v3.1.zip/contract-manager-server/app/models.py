"""نگاشت فیلدها (camelCase ↔ ستون‌های SQLite) و اعتبارسنجی/نرمال‌سازی ورودی‌ها.

کلاینت HTML بدون تبدیل کار می‌کند؛ نام فیلدهای JSON باید دقیقاً camelCase باشد.
اعتبارسنجی‌ها دستی هستند تا پیام خطای فارسی و کد وضعیت دقیق (422/409/404) حفظ شود.
"""
import re
import sqlite3
from datetime import datetime
from typing import Any, Dict, Optional, Set

from fastapi import HTTPException

from app.utils import new_id, norm_text, now_ms, to_latin_digits, validate_jalali

# ---------- ثابت‌های اعتبارسنجی ----------
MAX_TITLE_LEN = 200
MAX_COMPANY_LEN = 200
MAX_LOGO_LEN = 1024 * 1024  # ۱ مگابایت رشته
DURATION_UNITS = ("ماه", "روز", "سال")
PERSON_TYPES = ("حقیقی", "حقوقی")
GRADES = ("", "1", "2", "3", "4", "5")
PAGE_SIZES = (5, 10, 25, 50)
THEMES = ("light", "dark")
MOBILE_RE = re.compile(r"^09[0-9]{9}$")

# ---------- نگاشت camelCase → ستون ----------
CONTRACT_FIELD_MAP = {
    "id": "id",
    "contractNumber": "contract_number",
    "date": "date",
    "title": "title",
    "contractorId": "contractor_id",
    "deputyId": "deputy_id",
    "durationValue": "duration_value",
    "durationUnit": "duration_unit",
    "createdAt": "created_at",
}

CONTRACTOR_FIELD_MAP = {
    "id": "id",
    "name": "name",
    "type": "type",
    "grade": "grade",
    "mobile": "mobile",
    "address": "address",
    "createdAt": "created_at",
}

DEPUTY_FIELD_MAP = {
    "id": "id",
    "name": "name",
    "createdAt": "created_at",
}

SETTINGS_FIELD_MAP = {
    "id": "id",
    "companyName": "company_name",
    "logo": "logo",
    "theme": "theme",
    "generalSettings.pageSize": "page_size",
    "generalSettings.notificationsEnabled": "notifications_enabled",
}

BACKUP_FIELD_MAP = {
    "id": "id",
    "fileName": "file_name",
    "date": "date",
    "size": "size",
}

# ---------- تبدیل ردیف → dict (camelCase) ----------

def row_to_contract(row: sqlite3.Row) -> Dict[str, Any]:
    return {
        "id": row["id"],
        "contractNumber": row["contract_number"],
        "date": row["date"],
        "title": row["title"],
        "contractorId": row["contractor_id"],
        "deputyId": row["deputy_id"],
        "durationValue": row["duration_value"],
        "durationUnit": row["duration_unit"],
        "createdAt": row["created_at"],
    }


def row_to_contractor(row: sqlite3.Row) -> Dict[str, Any]:
    return {
        "id": row["id"],
        "name": row["name"],
        "type": row["type"],
        "grade": row["grade"],
        "mobile": row["mobile"],
        "address": row["address"],
        "createdAt": row["created_at"],
    }


def row_to_deputy(row: sqlite3.Row) -> Dict[str, Any]:
    return {
        "id": row["id"],
        "name": row["name"],
        "createdAt": row["created_at"],
    }


def row_to_settings(row: sqlite3.Row) -> Dict[str, Any]:
    return {
        "id": "app",
        "companyName": row["company_name"],
        "logo": row["logo"],
        "theme": row["theme"],
        "generalSettings": {
            "pageSize": row["page_size"],
            "notificationsEnabled": bool(row["notifications_enabled"]),
        },
    }


def row_to_backup(row: sqlite3.Row) -> Dict[str, Any]:
    return {
        "id": row["id"],
        "fileName": row["file_name"],
        "date": row["date"],
        "size": row["size"],
    }


def default_settings() -> Dict[str, Any]:
    """ساختار پیش‌فرض تنظیمات (وقتی رکورد در دیتابیس نیست)."""
    return {
        "id": "app",
        "companyName": "",
        "logo": "",
        "theme": "light",
        "generalSettings": {"pageSize": 10, "notificationsEnabled": True},
    }


# ---------- ابزارهای عمومی اعتبارسنجی ----------

def req_str(value: Any, msg: str) -> str:
    """رشته الزامی؛ در صورت خالی بودن خطای 422 با پیام فارسی."""
    if value is None:
        raise HTTPException(status_code=422, detail=msg)
    text = str(value).strip()
    if not text:
        raise HTTPException(status_code=422, detail=msg)
    return text


def opt_str(value: Any) -> str:
    """رشته اختیاری؛ None/غایب → رشته خالی."""
    if value is None:
        return ""
    return str(value).strip()


def coerce_int(value: Any) -> Optional[int]:
    """تبدیل بخشنده به عدد صحیح (رشته با ارقام فارسی هم پذیرفته می‌شود)."""
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value) if value.is_integer() else None
    if isinstance(value, str):
        text = to_latin_digits(value).strip()
        if re.fullmatch(r"-?[0-9]+", text):
            return int(text)
    return None


# ---------- بررسی موجودیت (با اتصال دیتابیس) ----------

def contractor_exists(conn: sqlite3.Connection, cid: str) -> bool:
    return conn.execute("SELECT 1 FROM contractors WHERE id = ?", (cid,)).fetchone() is not None


def deputy_exists(conn: sqlite3.Connection, did: str) -> bool:
    return conn.execute("SELECT 1 FROM deputies WHERE id = ?", (did,)).fetchone() is not None


# ---------- نرمال‌سازی رکوردها ----------

def normalize_contract(
    data: Any,
    conn: Optional[sqlite3.Connection] = None,
    contractor_ids: Optional[Set[str]] = None,
    deputy_ids: Optional[Set[str]] = None,
) -> Dict[str, Any]:
    """اعتبارسنجی + نرمال‌سازی رکورد قرارداد (POST/PUT/bulk/replace-all).

    conn برای بررسی وجود پیمانکار/معاونت در دیتابیس؛ در replace-all به‌جای آن
    مجموعه idهای معتبر (contractor_ids/deputy_ids) داده می‌شود.
    """
    if not isinstance(data, dict):
        raise HTTPException(status_code=422, detail="ساختار رکورد قرارداد معتبر نیست.")
    contract_number = req_str(data.get("contractNumber"), "شماره قرارداد الزامی است.")
    date = validate_jalali(data.get("date"))
    if date is None:
        raise HTTPException(status_code=422, detail="تاریخ قرارداد معتبر نیست.")
    title = req_str(data.get("title"), "عنوان قرارداد الزامی است.")
    if len(title) > MAX_TITLE_LEN:
        raise HTTPException(status_code=422, detail="عنوان قرارداد نمی‌تواند بیش از ۲۰۰ کاراکتر باشد.")
    contractor_id = opt_str(data.get("contractorId"))
    if not contractor_id:
        raise HTTPException(status_code=422, detail="پیمانکار انتخاب‌شده یافت نشد.")
    if conn is not None:
        if not contractor_exists(conn, contractor_id):
            raise HTTPException(status_code=422, detail="پیمانکار انتخاب‌شده یافت نشد.")
    elif contractor_ids is not None and contractor_id not in contractor_ids:
        raise HTTPException(status_code=422, detail="پیمانکار انتخاب‌شده یافت نشد.")
    deputy_id = opt_str(data.get("deputyId"))
    if not deputy_id:
        raise HTTPException(status_code=422, detail="معاونت انتخاب‌شده یافت نشد.")
    if conn is not None:
        if not deputy_exists(conn, deputy_id):
            raise HTTPException(status_code=422, detail="معاونت انتخاب‌شده یافت نشد.")
    elif deputy_ids is not None and deputy_id not in deputy_ids:
        raise HTTPException(status_code=422, detail="معاونت انتخاب‌شده یافت نشد.")
    duration_value = coerce_int(data.get("durationValue"))
    if duration_value is None or not (1 <= duration_value <= 1200):
        raise HTTPException(status_code=422, detail="مدت قرارداد باید عدد صحیح بین ۱ تا ۱۲۰۰ باشد.")
    unit = opt_str(data.get("durationUnit"))
    if unit not in DURATION_UNITS:
        unit = "ماه"  # واحد نامعتبر یا غایب → پیش‌فرض
    rid = opt_str(data.get("id")) or new_id()
    created_at = coerce_int(data.get("createdAt"))
    if created_at is None:
        created_at = now_ms()
    return {
        "id": rid,
        "contractNumber": contract_number,
        "date": date,
        "title": title,
        "contractorId": contractor_id,
        "deputyId": deputy_id,
        "durationValue": duration_value,
        "durationUnit": unit,
        "createdAt": created_at,
    }


def normalize_contractor(data: Any) -> Dict[str, Any]:
    """اعتبارسنجی + نرمال‌سازی رکورد پیمانکار."""
    if not isinstance(data, dict):
        raise HTTPException(status_code=422, detail="ساختار رکورد پیمانکار معتبر نیست.")
    name = req_str(data.get("name"), "نام پیمانکار الزامی است.")
    person_type = opt_str(data.get("type"))
    if person_type and person_type not in PERSON_TYPES:
        raise HTTPException(status_code=422, detail="نوع شخصیت معتبر نیست.")
    grade = to_latin_digits(opt_str(data.get("grade"))).strip()
    if grade not in GRADES:
        raise HTTPException(status_code=422, detail="گرید معتبر نیست.")
    mobile = to_latin_digits(opt_str(data.get("mobile")))
    if mobile and MOBILE_RE.match(mobile) is None:
        raise HTTPException(status_code=422, detail="شماره موبایل معتبر وارد کنید (مثال: 09123456789).")
    address = opt_str(data.get("address"))
    rid = opt_str(data.get("id")) or new_id()
    created_at = coerce_int(data.get("createdAt"))
    if created_at is None:
        created_at = now_ms()
    return {
        "id": rid,
        "name": name,
        "type": person_type,
        "grade": grade,
        "mobile": mobile,
        "address": address,
        "createdAt": created_at,
    }


def normalize_deputy(data: Any) -> Dict[str, Any]:
    """اعتبارسنجی + نرمال‌سازی رکورد معاونت."""
    if not isinstance(data, dict):
        raise HTTPException(status_code=422, detail="ساختار رکورد معاونت معتبر نیست.")
    name = req_str(data.get("name"), "نام معاونت الزامی است.")
    rid = opt_str(data.get("id")) or new_id()
    created_at = coerce_int(data.get("createdAt"))
    if created_at is None:
        created_at = now_ms()
    return {"id": rid, "name": name, "createdAt": created_at}


def normalize_backup(data: Any) -> Dict[str, Any]:
    """اعتبارسنجی + نرمال‌سازی رکورد سابقه پشتیبان (JSON کلاینت)."""
    if not isinstance(data, dict):
        raise HTTPException(status_code=422, detail="ساختار رکورد پشتیبان معتبر نیست.")
    file_name = req_str(data.get("fileName"), "نام فایل پشتیبان الزامی است.")
    size = coerce_int(data.get("size"))
    if size is None or size < 0:
        raise HTTPException(status_code=422, detail="حجم فایل معتبر نیست.")
    date = opt_str(data.get("date"))
    if not date:
        date = datetime.now().isoformat(timespec="seconds")
    rid = opt_str(data.get("id")) or new_id()
    return {"id": rid, "fileName": file_name, "date": date, "size": size}


def normalize_settings(data: Any, current: Dict[str, Any]) -> Dict[str, Any]:
    """ادغام تنظیمات ارسالی با مقادیر فعلی + اعتبارسنجی.

    - theme نامعتبر → 422؛ غایب → مقدار فعلی
    - pageSize خارج از {5,10,25,50} → بی‌صدا 10
    - لوگو بیش از ۱MB رشته → 422
    """
    if not isinstance(data, dict):
        raise HTTPException(status_code=422, detail="ساختار داده ارسالی معتبر نیست.")
    # نام شرکت
    company = data.get("companyName")
    if company is None:
        company = current.get("companyName", "")
    company = str(company)
    if len(company) > MAX_COMPANY_LEN:
        raise HTTPException(status_code=422, detail="نام شرکت نمی‌تواند بیش از ۲۰۰ کاراکتر باشد.")
    # لوگو (dataURL)
    logo = data.get("logo")
    if logo is None:
        logo = current.get("logo", "")
    logo = str(logo)
    if len(logo) > MAX_LOGO_LEN:
        raise HTTPException(status_code=422, detail="لوگو بیش از حد مجاز است.")
    # پوسته
    theme = data.get("theme")
    if theme in (None, ""):
        theme = current.get("theme", "light")
    theme = str(theme)
    if theme not in THEMES:
        raise HTTPException(status_code=422, detail="پوسته معتبر نیست.")
    # تنظیمات عمومی
    gs_in = data.get("generalSettings") if isinstance(data.get("generalSettings"), dict) else {}
    cur_gs = current.get("generalSettings") if isinstance(current.get("generalSettings"), dict) else {}
    page_size = gs_in.get("pageSize", data.get("pageSize", cur_gs.get("pageSize", 10)))
    ps = coerce_int(page_size)
    if ps not in PAGE_SIZES:
        ps = 10
    notif = gs_in.get("notificationsEnabled", data.get("notificationsEnabled", cur_gs.get("notificationsEnabled", True)))
    if isinstance(notif, bool):
        ne = notif
    elif isinstance(notif, (int, float)) and notif in (0, 1):
        ne = bool(notif)
    else:
        ne = bool(cur_gs.get("notificationsEnabled", True))
    return {
        "id": "app",
        "companyName": company,
        "logo": logo,
        "theme": theme,
        "generalSettings": {"pageSize": ps, "notificationsEnabled": ne},
    }
