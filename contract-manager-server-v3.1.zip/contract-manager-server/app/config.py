"""بارگذاری پیکربندی پروژه از config.json (کنار ریشه پروژه).

- BASE_DIR = پوشه‌ای که config.json در آن قرار دارد (والد app/)
- مسیرهای نسبی نسبت به BASE_DIR حل می‌شوند
- متغیر محیطی CONTRACTS_DB مسیر دیتابیس را override می‌کند
- اگر config.json نبود یا معیوب بود، همین پیش‌فرض‌ها استفاده می‌شوند
"""
import json
import os
from pathlib import Path
from typing import Any, Dict

# نسخه سرور (با نسخه کلاینت HTML هماهنگ است)
APP_VERSION = "3.1.0"

# ریشه پروژه = والد پوشه app
BASE_DIR = Path(__file__).resolve().parent.parent

_DEFAULTS: Dict[str, Any] = {
    "host": "127.0.0.1",
    "port": 8000,
    "dbPath": "data/contracts.db",
    "backupDir": "data/backups",
    "uiDir": "ui",
}


def _load_config() -> Dict[str, Any]:
    cfg: Dict[str, Any] = dict(_DEFAULTS)
    path = BASE_DIR / "config.json"
    try:
        if path.is_file():
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict):
                for key in _DEFAULTS:
                    if data.get(key) not in (None, ""):
                        cfg[key] = data[key]
    except Exception:
        # config.json معیوب است → پیش‌فرض‌ها
        pass
    try:
        cfg["port"] = int(cfg["port"])
    except Exception:
        cfg["port"] = 8000
    # override با متغیر محیطی
    env_db = os.environ.get("CONTRACTS_DB")
    if env_db:
        cfg["dbPath"] = env_db
    return cfg


_CONFIG = _load_config()


def _resolve(p: Any) -> Path:
    """مسیر نسبی را نسبت به BASE_DIR حل می‌کند؛ مسیر مطلق دست‌نخورده می‌ماند."""
    path = Path(str(p))
    return path if path.is_absolute() else (BASE_DIR / path)


HOST: str = str(_CONFIG["host"])
PORT: int = int(_CONFIG["port"])
DB_PATH: Path = _resolve(_CONFIG["dbPath"])
BACKUP_DIR: Path = _resolve(_CONFIG["backupDir"])
UI_DIR: Path = _resolve(_CONFIG["uiDir"])
