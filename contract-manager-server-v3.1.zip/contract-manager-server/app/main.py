"""نقطه ورود FastAPI — سامانه مدیریت قراردادهای پیمانکاری (سرور محلی).

- CORS باز (allow_origins=*) چون کلاینت ممکن است از file:// با Origin=null بیاید
- /api/health برای تشخیص اتصال کلاینت و پینگ run_server.py
- پوشه ui/ (در صورت وجود) به‌عنوان رابط استاتیک بعد از روترهای API سرو می‌شود
"""
import traceback
from contextlib import asynccontextmanager
from typing import Any, Dict

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError  # در همه نسخه‌های fastapi>=0.115 موجود است
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from app.config import APP_VERSION, BACKUP_DIR, DB_PATH, HOST, PORT, UI_DIR
from app.database import db_session, init_db
from app.routers import backups, contracts, contractors, data, dbfile, deputies, settings


@asynccontextmanager
async def lifespan(_app: FastAPI):
    # آماده‌سازی دیتابیس (ساخت پوشه‌ها، جداول، WAL، مقادیر اولیه)
    init_db()
    _print_banner()
    yield


app = FastAPI(
    title="سامانه مدیریت قراردادهای پیمانکاری — سرور محلی",
    version=APP_VERSION,
    lifespan=lifespan,
)

# CORS باز برای file:// (Origin=null) و هر مبدا دیگر؛ بدون credentials
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---------- روترهای API (قبل از استاتیک تا /api مقدم باشد) ----------
app.include_router(contracts.router)
app.include_router(contractors.router)
app.include_router(deputies.router)
app.include_router(settings.router)
app.include_router(backups.router)
app.include_router(data.router)
app.include_router(data.migration_router)
app.include_router(dbfile.router)


# ---------- سلامت سرور ----------
@app.get("/api/health")
def health():
    db_status = "ok"
    try:
        with db_session() as conn:
            conn.execute("SELECT 1").fetchone()
    except Exception:
        db_status = "error"
    return {
        "status": "ok",
        "version": APP_VERSION,
        "database": db_status,
        "databasePath": str(DB_PATH),
    }


# ---------- خطاها ----------
@app.exception_handler(RequestValidationError)
async def validation_error_handler(_request: Request, _exc: RequestValidationError):
    # خطاهای ساختاری بدنه (مثلاً JSON نامعتبر) با پیام فارسی
    return JSONResponse(status_code=422, content={"detail": "داده ارسالی معتبر نیست."})


@app.exception_handler(Exception)
async def unhandled_error_handler(_request: Request, exc: Exception):
    # خطای داخلی: پیام فارسی به کلاینت + traceback در کنسول
    traceback.print_exc()
    return JSONResponse(status_code=500, content={"detail": "خطای داخلی سرور"})


# ---------- رابط کاربری استاتیک (اختیاری) ----------
if UI_DIR.is_dir():
    # mount در "/" بعد از include_router‌ها → مسیرهای /api مقدم هستند
    # با html=True در صورت وجود index.html در "/" سرو می‌شود
    app.mount("/", StaticFiles(directory=str(UI_DIR), html=True), name="ui")
else:

    @app.get("/")
    def root_fallback():
        return JSONResponse(
            {
                "status": "ok",
                "message": "سرور فعال است؛ پوشه ui یافت نشد.",
                "docs": "/docs",
                "health": "/api/health",
            }
        )


def _print_banner() -> None:
    """بنر فارسی شروع (در کنسول‌های بدون پشتیبانی یونیکد خطا نمی‌دهد)."""
    line = "=" * 62
    try:
        print(line)
        print("  سامانه مدیریت قراردادهای پیمانکاری — سرور محلی")
        print("  نسخه: {}".format(APP_VERSION))
        print("  آدرس: http://{}:{}".format(HOST, PORT))
        print("  دیتابیس: {}".format(DB_PATH))
        print("  بکاپ‌ها: {}".format(BACKUP_DIR))
        print(line)
        print("  برای توقف: Ctrl+C")
    except Exception:
        pass
