"""لایه دسترسی به SQLite (بدون ORM).

- به‌ازای هر درخواست یک اتصال تازه باز و در پایان بسته می‌شود
- db_session: context manager با commit/rollback خودکار
- init_db: ساخت پوشه‌ها، اجرای schema.sql، WAL و مقادیر اولیه (یک بار در استارتاپ)
"""
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

from app.config import BACKUP_DIR, DB_PATH

SCHEMA_PATH = Path(__file__).resolve().parent / "schema.sql"

# جداول الزامی برای بررسی سلامت
EXPECTED_TABLES = (
    "contracts", "contractors", "deputies", "settings", "backup_history", "schema_version",
)


def get_db() -> sqlite3.Connection:
    """اتصال تازه با row_factory و PRAGMA foreign_keys=ON."""
    conn = sqlite3.connect(str(DB_PATH), timeout=15.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


@contextmanager
def db_session() -> Iterator[sqlite3.Connection]:
    """اتصال با commit/rollback خودکار: در خطا rollback، در موفقیت commit."""
    conn = get_db()
    try:
        yield conn
        conn.commit()
    except Exception:
        try:
            conn.rollback()
        except Exception:
            pass
        raise
    finally:
        conn.close()


def init_db() -> None:
    """آماده‌سازی دیتابیس — فقط یک بار در استارتاپ سرور."""
    # ساخت پوشه‌های لازم (data و data/backups)
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)

    conn = sqlite3.connect(str(DB_PATH), timeout=15.0)
    conn.row_factory = sqlite3.Row
    try:
        # حالت WAL (یک بار در استارتاپ)
        conn.execute("PRAGMA journal_mode = WAL")
        # اجرای کامل اسکیما
        conn.executescript(SCHEMA_PATH.read_text(encoding="utf-8"))

        # درج نسخه اسکیما اگر ردیفی نیست
        row = conn.execute("SELECT COUNT(*) AS c FROM schema_version").fetchone()
        if row is None or row["c"] == 0:
            conn.execute("INSERT INTO schema_version (version) VALUES (1)")

        # درج رکورد پیش‌فرض تنظیمات اگر نیست
        row = conn.execute("SELECT COUNT(*) AS c FROM settings").fetchone()
        if row is None or row["c"] == 0:
            conn.execute(
                "INSERT INTO settings (id, company_name, logo, theme, page_size, notifications_enabled) "
                "VALUES ('app', '', '', 'light', 10, 1)"
            )
        conn.commit()

        # بررسی سلامت و شمارش جداول
        integrity = conn.execute("PRAGMA integrity_check").fetchone()[0]
        tables = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        missing = [t for t in EXPECTED_TABLES if t not in tables]
        if integrity != "ok" or missing:
            raise RuntimeError(
                "init_db failed: integrity={} missing={}".format(integrity, missing)
            )
        try:
            print("دیتابیس آماده است: {} (سلامت: ok، جداول: {}/6)".format(DB_PATH, len(tables & set(EXPECTED_TABLES))))
        except Exception:
            pass
    finally:
        conn.close()
