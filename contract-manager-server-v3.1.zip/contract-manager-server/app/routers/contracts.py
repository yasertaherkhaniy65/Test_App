"""CRUD قراردادها — /api/contracts (ورودی/خروجی camelCase)."""
import sqlite3
from typing import Any, Dict, Optional

from fastapi import APIRouter, Body, HTTPException, Response

from app.database import db_session
from app.models import normalize_contract, req_str, row_to_contract
from app.utils import norm_text

router = APIRouter(prefix="/api/contracts", tags=["Contracts"])


# ---------- کمک‌تابع‌های مشترک (در عملیات گروهی data.py هم استفاده می‌شوند) ----------

def get_contract(conn: sqlite3.Connection, cid: str) -> Optional[Dict[str, Any]]:
    row = conn.execute("SELECT * FROM contracts WHERE id = ?", (cid,)).fetchone()
    return row_to_contract(row) if row is not None else None


def number_owner(conn: sqlite3.Connection, norm: str, exclude_id: Optional[str] = None) -> Optional[str]:
    """مالک فعلی شماره قرارداد نرمال‌شده (به‌جز رکورد خود فرد)."""
    if exclude_id is None:
        row = conn.execute(
            "SELECT id FROM contracts WHERE contract_number_norm = ?", (norm,)
        ).fetchone()
    else:
        row = conn.execute(
            "SELECT id FROM contracts WHERE contract_number_norm = ? AND id <> ?", (norm, exclude_id)
        ).fetchone()
    return row["id"] if row is not None else None


def insert_contract(conn: sqlite3.Connection, d: Dict[str, Any]) -> Dict[str, Any]:
    try:
        conn.execute(
            "INSERT INTO contracts (id, contract_number, contract_number_norm, date, title, "
            "contractor_id, deputy_id, duration_value, duration_unit, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                d["id"], d["contractNumber"], norm_text(d["contractNumber"]), d["date"], d["title"],
                d["contractorId"], d["deputyId"], d["durationValue"], d["durationUnit"], d["createdAt"],
            ),
        )
    except sqlite3.IntegrityError:
        # دفاع دوم در سطح دیتابیس (یکتایی شماره / FK)
        raise HTTPException(status_code=409, detail="این شماره قرارداد قبلاً ثبت شده است.")
    return get_contract(conn, d["id"])


def update_contract(conn: sqlite3.Connection, cid: str, d: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    try:
        cur = conn.execute(
            "UPDATE contracts SET contract_number = ?, contract_number_norm = ?, date = ?, title = ?, "
            "contractor_id = ?, deputy_id = ?, duration_value = ?, duration_unit = ?, created_at = ? "
            "WHERE id = ?",
            (
                d["contractNumber"], norm_text(d["contractNumber"]), d["date"], d["title"],
                d["contractorId"], d["deputyId"], d["durationValue"], d["durationUnit"],
                d["createdAt"], cid,
            ),
        )
    except sqlite3.IntegrityError:
        raise HTTPException(status_code=409, detail="این شماره قرارداد قبلاً ثبت شده است.")
    if cur.rowcount == 0:
        return None
    return get_contract(conn, cid)


# ---------- Endpointها ----------

@router.get("")
def list_contracts():
    """لیست کامل قراردادها — مرتب بر اساس createdAt نزولی."""
    with db_session() as conn:
        rows = conn.execute("SELECT * FROM contracts ORDER BY created_at DESC, rowid DESC").fetchall()
    return [row_to_contract(r) for r in rows]


@router.post("", status_code=201)
def create_contract(data: Dict[str, Any] = Body(...)):
    # ۱) شماره قرارداد الزامی است
    number = req_str(data.get("contractNumber"), "شماره قرارداد الزامی است.")
    with db_session() as conn:
        # ۲) یکتایی شماره (نرمال‌شده)
        if number_owner(conn, norm_text(number)) is not None:
            raise HTTPException(status_code=409, detail="این شماره قرارداد قبلاً ثبت شده است.")
        # ۳) بقیه قواعد به‌ترتیب: تاریخ، عنوان، وجود پیمانکار/معاونت، مدت
        d = normalize_contract(data, conn=conn)
        saved = insert_contract(conn, d)
    return saved


@router.put("/{contract_id}")
def update_contract_endpoint(contract_id: str, data: Dict[str, Any] = Body(...)):
    number = req_str(data.get("contractNumber"), "شماره قرارداد الزامی است.")
    with db_session() as conn:
        existing = get_contract(conn, contract_id)
        if existing is None:
            raise HTTPException(status_code=404, detail="قرارداد یافت نشد.")
        # یکتایی شماره به‌جز خود رکورد
        if number_owner(conn, norm_text(number), exclude_id=contract_id) is not None:
            raise HTTPException(status_code=409, detail="این شماره قرارداد قبلاً ثبت شده است.")
        d = normalize_contract(data, conn=conn)
        d["createdAt"] = existing["createdAt"]  # زمان ایجاد اصلی حفظ می‌شود
        updated = update_contract(conn, contract_id, d)
    return updated


@router.delete("/{contract_id}", status_code=204)
def delete_contract(contract_id: str):
    with db_session() as conn:
        cur = conn.execute("DELETE FROM contracts WHERE id = ?", (contract_id,))
        if cur.rowcount == 0:
            raise HTTPException(status_code=404, detail="قرارداد یافت نشد.")
    return Response(status_code=204)
