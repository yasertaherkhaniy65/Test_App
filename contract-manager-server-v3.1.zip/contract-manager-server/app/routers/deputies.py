"""CRUD معاونت‌ها — /api/deputies (ورودی/خروجی camelCase)."""
import sqlite3
from typing import Any, Dict, Optional

from fastapi import APIRouter, Body, HTTPException, Response

from app.database import db_session
from app.models import normalize_deputy, req_str, row_to_deputy
from app.utils import norm_text

router = APIRouter(prefix="/api/deputies", tags=["Deputies"])


# ---------- کمک‌تابع‌های مشترک ----------

def get_deputy(conn: sqlite3.Connection, did: str) -> Optional[Dict[str, Any]]:
    row = conn.execute("SELECT * FROM deputies WHERE id = ?", (did,)).fetchone()
    return row_to_deputy(row) if row is not None else None


def name_owner(conn: sqlite3.Connection, norm: str, exclude_id: Optional[str] = None) -> Optional[str]:
    """مالک فعلی نام نرمال‌شده (به‌جز رکورد خود فرد)."""
    if exclude_id is None:
        row = conn.execute("SELECT id FROM deputies WHERE name_norm = ?", (norm,)).fetchone()
    else:
        row = conn.execute(
            "SELECT id FROM deputies WHERE name_norm = ? AND id <> ?", (norm, exclude_id)
        ).fetchone()
    return row["id"] if row is not None else None


def insert_deputy(conn: sqlite3.Connection, d: Dict[str, Any]) -> Dict[str, Any]:
    try:
        conn.execute(
            "INSERT INTO deputies (id, name, name_norm, created_at) VALUES (?, ?, ?, ?)",
            (d["id"], d["name"], norm_text(d["name"]), d["createdAt"]),
        )
    except sqlite3.IntegrityError:
        raise HTTPException(status_code=409, detail="معاونتی با این نام قبلاً ثبت شده است.")
    return get_deputy(conn, d["id"])


def update_deputy(conn: sqlite3.Connection, did: str, d: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    try:
        cur = conn.execute(
            "UPDATE deputies SET name = ?, name_norm = ?, created_at = ? WHERE id = ?",
            (d["name"], norm_text(d["name"]), d["createdAt"], did),
        )
    except sqlite3.IntegrityError:
        raise HTTPException(status_code=409, detail="معاونتی با این نام قبلاً ثبت شده است.")
    if cur.rowcount == 0:
        return None
    return get_deputy(conn, did)


# ---------- Endpointها ----------

@router.get("")
def list_deputies():
    """لیست معاونت‌ها — مرتب‌سازی فارسی با کلید نرمال‌شده."""
    with db_session() as conn:
        rows = conn.execute("SELECT * FROM deputies").fetchall()
    items = [row_to_deputy(r) for r in rows]
    items.sort(key=lambda d: norm_text(d["name"]))
    return items


@router.post("", status_code=201)
def create_deputy(data: Dict[str, Any] = Body(...)):
    name = req_str(data.get("name"), "نام معاونت الزامی است.")
    with db_session() as conn:
        if name_owner(conn, norm_text(name)) is not None:
            raise HTTPException(status_code=409, detail="معاونتی با این نام قبلاً ثبت شده است.")
        d = normalize_deputy(data)
        saved = insert_deputy(conn, d)
    return saved


@router.put("/{deputy_id}")
def update_deputy_endpoint(deputy_id: str, data: Dict[str, Any] = Body(...)):
    name = req_str(data.get("name"), "نام معاونت الزامی است.")
    with db_session() as conn:
        existing = get_deputy(conn, deputy_id)
        if existing is None:
            raise HTTPException(status_code=404, detail="معاونت یافت نشد.")
        # یکتایی نام به‌جز خود رکورد
        if name_owner(conn, norm_text(name), exclude_id=deputy_id) is not None:
            raise HTTPException(status_code=409, detail="معاونتی با این نام قبلاً ثبت شده است.")
        d = normalize_deputy(data)
        d["createdAt"] = existing["createdAt"]  # زمان ایجاد اصلی حفظ می‌شود
        updated = update_deputy(conn, deputy_id, d)
    return updated


@router.delete("/{deputy_id}", status_code=204)
def delete_deputy(deputy_id: str):
    with db_session() as conn:
        if get_deputy(conn, deputy_id) is None:
            raise HTTPException(status_code=404, detail="معاونت یافت نشد.")
        # چک صریح استفاده در قراردادها
        used = conn.execute(
            "SELECT 1 FROM contracts WHERE deputy_id = ? LIMIT 1", (deputy_id,)
        ).fetchone()
        if used is not None:
            raise HTTPException(status_code=409, detail="این معاونت در قراردادها استفاده شده و قابل حذف نیست.")
        try:
            conn.execute("DELETE FROM deputies WHERE id = ?", (deputy_id,))
        except sqlite3.IntegrityError:
            # دفاع دوم (FK RESTRICT)
            raise HTTPException(status_code=409, detail="این معاونت در قراردادها استفاده شده و قابل حذف نیست.")
    return Response(status_code=204)
