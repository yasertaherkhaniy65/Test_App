"""پشتیبان‌گیری/بازیابی فایل دیتابیس SQLite — /api/db.

- POST /api/db/backup            → کپی سازگار با sqlite3 backup API
- GET  /api/db/backup/download   → دانلود فایل بکاپ (با محافظت نام)
- GET  /api/db/backups           → لیست فایل‌های بکاپ
- POST /api/db/restore           → بازیابی فایل .db با بکاپ اضطراری و جایگزینی اتمیک
"""
import os
import re
import sqlite3
import tempfile
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List

from fastapi import APIRouter, File, HTTPException, Query, UploadFile
from fastapi.responses import FileResponse

from app.config import BACKUP_DIR, DB_PATH
from app.database import get_db

router = APIRouter(prefix="/api/db", tags=["DB File"])

# فقط نام‌های تولیدشده توسط همین سرور مجاز به دانلود هستند (بدون / و ..)
BACKUP_NAME_RE = re.compile(r"^contracts-backup-[0-9-]+\.db$")
MAX_RESTORE_SIZE = 50 * 1024 * 1024  # ۵۰ مگابایت
REQUIRED_TABLES = ("contracts", "contractors", "deputies", "settings")


def _ensure_backup_dir() -> None:
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)


def _unique_path(base_name: str) -> Path:
    """انتخاب مسیر یکتا؛ در صورت تکرار نام، پسوند -1، -2 و... اضافه می‌شود."""
    path = BACKUP_DIR / base_name
    if not path.exists():
        return path
    stem, suffix = path.stem, path.suffix
    n = 1
    while True:
        candidate = BACKUP_DIR / "{}-{}{}".format(stem, n, suffix)
        if not candidate.exists():
            return candidate
        n += 1


def _remove_sidecars() -> None:
    """حذف فایل‌های -wal و -shm (پس از checkpoint تا داده‌ای از دست نرود)."""
    for side in (str(DB_PATH) + "-wal", str(DB_PATH) + "-shm"):
        try:
            os.remove(side)
        except OSError:
            pass


def create_backup_file(prefix: str = "contracts-backup-") -> Path:
    """ساخت یک کپی سازگار از دیتابیس فعال با API استاندارد backup.

    قبل از بکاپ، WAL با wal_checkpoint(TRUNCATE) ادغام می‌شود.
    """
    _ensure_backup_dir()
    ts = datetime.now().strftime("%Y%m%d-%H%M%S")
    dest_path = _unique_path("{}{}.db".format(prefix, ts))
    src = get_db()
    try:
        try:
            src.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        except sqlite3.Error:
            pass  # در صورت قفل، snapshot با API backup همچنان سازگار است
        dest = sqlite3.connect(str(dest_path))
        try:
            src.backup(dest)
        finally:
            dest.close()
    finally:
        src.close()
    return dest_path


# ---------- POST /api/db/backup ----------

@router.post("/backup")
def backup_db():
    path = create_backup_file()
    return {
        "fileName": path.name,
        "sizeBytes": path.stat().st_size,
        "createdAt": datetime.now().isoformat(timespec="seconds"),
    }


# ---------- GET /api/db/backup/download ----------

@router.get("/backup/download")
def download_backup(name: str = Query(default="")):
    if not BACKUP_NAME_RE.match(name or ""):
        raise HTTPException(status_code=400, detail="نام فایل مجاز نیست.")
    _ensure_backup_dir()
    path = BACKUP_DIR / name
    # محافظت اضافه در برابر path traversal
    real_backup_dir = os.path.realpath(str(BACKUP_DIR))
    real_path = os.path.realpath(str(path))
    if not real_path.startswith(real_backup_dir + os.sep):
        raise HTTPException(status_code=400, detail="نام فایل مجاز نیست.")
    if not path.is_file():
        raise HTTPException(status_code=404, detail="فایل پشتیبان یافت نشد.")
    return FileResponse(str(path), media_type="application/octet-stream", filename=name)


# ---------- GET /api/db/backups ----------

@router.get("/backups")
def list_backup_files():
    """لیست فایل‌های .db داخل پوشه بکاپ (برای نمایش در UI)."""
    _ensure_backup_dir()
    files: List[Dict[str, Any]] = []
    for p in BACKUP_DIR.glob("*.db"):
        if p.is_file():
            stat = p.stat()
            files.append(
                {
                    "fileName": p.name,
                    "sizeBytes": stat.st_size,
                    "createdAt": datetime.fromtimestamp(stat.st_mtime).isoformat(timespec="seconds"),
                }
            )
    files.sort(key=lambda f: f["createdAt"], reverse=True)
    return {"files": files}


# ---------- POST /api/db/restore ----------

def _validate_sqlite_file(path: str) -> None:
    """بررسی سلامت و سازگاری فایل دیتابیس ورودی."""
    try:
        conn = sqlite3.connect(path)
        try:
            integrity = conn.execute("PRAGMA integrity_check").fetchone()[0]
            tables = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        finally:
            conn.close()
    except sqlite3.Error:
        raise HTTPException(status_code=400, detail="فایل دیتابیس معتبر یا سازگار نیست.")
    if integrity != "ok" or any(t not in tables for t in REQUIRED_TABLES):
        raise HTTPException(status_code=400, detail="فایل دیتابیس معتبر یا سازگار نیست.")


@router.post("/restore")
def restore_db(file: UploadFile = File(...)):
    """بازیابی فایل .db: اعتبارسنجی → بکاپ اضطراری → جایگزینی اتمیک → بررسی سلامت."""
    _ensure_backup_dir()
    tmp_name: Optional[str] = None
    try:
        # ۱) ذخیره موقت با محدودیت حجم ۵۰ مگابایت
        fd, tmp_name = tempfile.mkstemp(prefix="restore-", suffix=".db")
        os.close(fd)
        total = 0
        with open(tmp_name, "wb") as out:
            while True:
                chunk = file.file.read(1024 * 1024)
                if not chunk:
                    break
                total += len(chunk)
                if total > MAX_RESTORE_SIZE:
                    raise HTTPException(status_code=400, detail="حجم فایل بیش از حد مجاز است.")
                out.write(chunk)
        # ۲) اعتبارسنجی فایل (integrity + وجود جداول الزامی)
        _validate_sqlite_file(tmp_name)
        # ۳) بکاپ اضطراری از وضعیت فعلی
        emergency_path = create_backup_file(prefix="emergency-")
        # ۴) جایگزینی اتمیک
        src = get_db()
        try:
            src.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        except sqlite3.Error:
            pass
        finally:
            src.close()
        _remove_sidecars()  # WAL کهنه نباید روی فایل جدید اعمال شود
        os.replace(tmp_name, str(DB_PATH))
        tmp_name = None  # فایل منتقل شد؛ در finally پاک نشود
        _remove_sidecars()
        # ۵) بررسی سلامت فایل جدید از اتصال تازه + شمارش رکوردها
        conn = get_db()
        try:
            integrity = conn.execute("PRAGMA integrity_check").fetchone()[0]
            counts = {
                "contracts": conn.execute("SELECT COUNT(*) FROM contracts").fetchone()[0],
                "contractors": conn.execute("SELECT COUNT(*) FROM contractors").fetchone()[0],
                "deputies": conn.execute("SELECT COUNT(*) FROM deputies").fetchone()[0],
            }
        finally:
            conn.close()
        return {
            "restored": True,
            "emergencyBackup": emergency_path.name,
            "integrity": integrity,
            "counts": counts,
        }
    except HTTPException:
        raise
    except sqlite3.Error:
        raise HTTPException(status_code=400, detail="بازیابی فایل دیتابیس با خطا مواجه شد.")
    except OSError:
        raise HTTPException(
            status_code=400,
            detail="جایگزینی فایل دیتابیس ممکن نشد؛ احتمالاً فایل در حال استفاده است.",
        )
    finally:
        if tmp_name and os.path.exists(tmp_name):
            try:
                os.remove(tmp_name)
            except OSError:
                pass
