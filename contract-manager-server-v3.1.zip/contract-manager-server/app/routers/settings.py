"""تنظیمات برنامه — /api/settings (ساختار تو در تو با generalSettings)."""
import sqlite3
from typing import Any, Dict

from fastapi import APIRouter, Body

from app.database import db_session
from app.models import default_settings, normalize_settings, row_to_settings

router = APIRouter(prefix="/api/settings", tags=["Settings"])


def save_settings(conn: sqlite3.Connection, d: Dict[str, Any]) -> None:
    """ذخیره رکورد تنظیمات (id همیشه 'app')."""
    gs = d["generalSettings"]
    row = conn.execute("SELECT id FROM settings WHERE id = 'app'").fetchone()
    if row is None:
        conn.execute(
            "INSERT INTO settings (id, company_name, logo, theme, page_size, notifications_enabled) "
            "VALUES ('app', ?, ?, ?, ?, ?)",
            (d["companyName"], d["logo"], d["theme"], gs["pageSize"], 1 if gs["notificationsEnabled"] else 0),
        )
    else:
        conn.execute(
            "UPDATE settings SET company_name = ?, logo = ?, theme = ?, page_size = ?, "
            "notifications_enabled = ? WHERE id = 'app'",
            (d["companyName"], d["logo"], d["theme"], gs["pageSize"], 1 if gs["notificationsEnabled"] else 0),
        )


@router.get("")
def get_settings():
    """رکورد تنظیمات — همیشه موجود است (در صورت نبود، پیش‌فرض ساخته می‌شود)."""
    with db_session() as conn:
        row = conn.execute("SELECT * FROM settings WHERE id = 'app'").fetchone()
        if row is None:
            save_settings(conn, default_settings())
            row = conn.execute("SELECT * FROM settings WHERE id = 'app'").fetchone()
        return row_to_settings(row)


@router.put("")
def update_settings(data: Dict[str, Any] = Body(...)):
    """ذخیره تنظیمات — فیلدهای غایب از مقادیر فعلی حفظ می‌شوند."""
    with db_session() as conn:
        row = conn.execute("SELECT * FROM settings WHERE id = 'app'").fetchone()
        current = row_to_settings(row) if row is not None else default_settings()
        d = normalize_settings(data, current)
        save_settings(conn, d)
        row = conn.execute("SELECT * FROM settings WHERE id = 'app'").fetchone()
        return row_to_settings(row)
