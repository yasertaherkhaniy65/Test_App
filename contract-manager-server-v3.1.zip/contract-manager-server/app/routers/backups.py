"""سابقه پشتیبان‌گیری JSON کلاینت — /api/backups.

این جدول فقط «تاریخچه» بکاپ‌های JSON است که کلاینت ثبت می‌کند؛
فایل‌های بکاپ SQLite در router جداگانه (dbfile.py) مدیریت می‌شوند.
"""
import sqlite3
from typing import Any, Dict

from fastapi import APIRouter, Body, HTTPException, Response

from app.database import db_session
from app.models import normalize_backup, row_to_backup

router = APIRouter(prefix="/api/backups", tags=["Backups"])


def insert_backup(conn: sqlite3.Connection, d: Dict[str, Any]) -> None:
    """درج/به‌روزرسانی رکورد سابقه (idempotent بر اساس id)."""
    conn.execute(
        "INSERT OR REPLACE INTO backup_history (id, file_name, date, size) VALUES (?, ?, ?, ?)",
        (d["id"], d["fileName"], d["date"], d["size"]),
    )


@router.get("")
def list_backups():
    """لیست سابقه پشتیبان‌ها — مرتب بر اساس date نزولی."""
    with db_session() as conn:
        rows = conn.execute("SELECT * FROM backup_history ORDER BY date DESC, rowid DESC").fetchall()
    return [row_to_backup(r) for r in rows]


@router.post("", status_code=201)
def create_backup_record(data: Dict[str, Any] = Body(...)):
    d = normalize_backup(data)
    with db_session() as conn:
        insert_backup(conn, d)
    return d


@router.delete("/{backup_id}", status_code=204)
def delete_backup_record(backup_id: str):
    with db_session() as conn:
        cur = conn.execute("DELETE FROM backup_history WHERE id = ?", (backup_id,))
        if cur.rowcount == 0:
            raise HTTPException(status_code=404, detail="سابقه پشتیبان یافت نشد.")
    return Response(status_code=204)
