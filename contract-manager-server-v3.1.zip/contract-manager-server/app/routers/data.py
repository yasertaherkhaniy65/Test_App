"""ابزارهای گروهی و مهاجرت — /api/data و /api/migration.

- GET  /api/data/all            → کل داده‌ها در یک پاسخ (init سریع کلاینت)
- POST /api/data/bulk/{store}   → درج/به‌روزرسانی گروهی در یک تراکنش
- DEL  /api/data/clear/{store}  → پاک‌سازی یک مجموعه
- POST /api/data/replace-all    → جایگزینی اتمیک سه جدول اصلی (Restore JSON)
- POST /api/migration/import    → replace-all + تنظیمات (انتقال IndexedDB → SQLite)
"""
import sqlite3
from typing import Any, Callable, Dict, List, Optional

from fastapi import APIRouter, Body, HTTPException

from app.database import db_session
from app.models import (
    default_settings,
    normalize_backup,
    normalize_contract,
    normalize_contractor,
    normalize_deputy,
    normalize_settings,
    row_to_backup,
    row_to_contract,
    row_to_contractor,
    row_to_deputy,
    row_to_settings,
)
from app.routers.backups import insert_backup
from app.routers.contracts import get_contract, insert_contract, number_owner, update_contract
from app.routers.contractors import (
    get_contractor,
    insert_contractor,
    name_owner as contractor_name_owner,
    update_contractor,
)
from app.routers.deputies import (
    get_deputy,
    insert_deputy,
    name_owner as deputy_name_owner,
    update_deputy,
)
from app.routers.settings import save_settings
from app.utils import norm_text

router = APIRouter(prefix="/api/data", tags=["Data"])
migration_router = APIRouter(prefix="/api/migration", tags=["Migration"])

# مجموعه‌های مجاز برای عملیات گروهی
STORES = ("contracts", "contractors", "deputies", "backups")


def _indexed_error(i: int, exc: HTTPException) -> HTTPException:
    """خطای استاندارد رکورد خراب در عملیات گروهی (شماره از ۱)."""
    return HTTPException(status_code=422, detail="رکورد شماره {} معتبر نیست: {}".format(i + 1, exc.detail))


# ---------- GET /api/data/all ----------

@router.get("/all")
def get_all_data():
    """کل داده‌ها در یک پاسخ — برای init و Migration."""
    with db_session() as conn:
        contracts = [
            row_to_contract(r)
            for r in conn.execute("SELECT * FROM contracts ORDER BY created_at DESC, rowid DESC").fetchall()
        ]
        contractors = [row_to_contractor(r) for r in conn.execute("SELECT * FROM contractors").fetchall()]
        deputies = [row_to_deputy(r) for r in conn.execute("SELECT * FROM deputies").fetchall()]
        srow = conn.execute("SELECT * FROM settings WHERE id = 'app'").fetchone()
        backups = [
            row_to_backup(r)
            for r in conn.execute("SELECT * FROM backup_history ORDER BY date DESC, rowid DESC").fetchall()
        ]
    # مرتب‌سازی فارسی نام‌ها
    contractors.sort(key=lambda c: norm_text(c["name"]))
    deputies.sort(key=lambda d: norm_text(d["name"]))
    return {
        "contracts": contracts,
        "contractors": contractors,
        "deputies": deputies,
        "settings": row_to_settings(srow) if srow is not None else default_settings(),
        "backups": backups,
    }


# ---------- POST /api/data/bulk/{store} ----------

def _bulk_contracts(conn: sqlite3.Connection, records: List[Any]) -> int:
    seen_norms: Dict[str, str] = {}
    for i, rec in enumerate(records):
        try:
            d = normalize_contract(rec, conn=conn)
            norm = norm_text(d["contractNumber"])
            owner = seen_norms.get(norm) or number_owner(conn, norm, exclude_id=d["id"])
            if owner is not None and owner != d["id"]:
                raise HTTPException(status_code=409, detail="این شماره قرارداد قبلاً ثبت شده است.")
            if get_contract(conn, d["id"]) is not None:
                update_contract(conn, d["id"], d)
            else:
                insert_contract(conn, d)
            seen_norms[norm] = d["id"]
        except HTTPException as exc:
            raise _indexed_error(i, exc)
    return len(records)


def _bulk_contractors(conn: sqlite3.Connection, records: List[Any]) -> int:
    seen_norms: Dict[str, str] = {}
    for i, rec in enumerate(records):
        try:
            d = normalize_contractor(rec)
            norm = norm_text(d["name"])
            owner = seen_norms.get(norm) or contractor_name_owner(conn, norm, exclude_id=d["id"])
            if owner is not None and owner != d["id"]:
                raise HTTPException(status_code=409, detail="پیمانکاری با این نام قبلاً ثبت شده است.")
            if get_contractor(conn, d["id"]) is not None:
                update_contractor(conn, d["id"], d)
            else:
                insert_contractor(conn, d)
            seen_norms[norm] = d["id"]
        except HTTPException as exc:
            raise _indexed_error(i, exc)
    return len(records)


def _bulk_deputies(conn: sqlite3.Connection, records: List[Any]) -> int:
    seen_norms: Dict[str, str] = {}
    for i, rec in enumerate(records):
        try:
            d = normalize_deputy(rec)
            norm = norm_text(d["name"])
            owner = seen_norms.get(norm) or deputy_name_owner(conn, norm, exclude_id=d["id"])
            if owner is not None and owner != d["id"]:
                raise HTTPException(status_code=409, detail="معاونتی با این نام قبلاً ثبت شده است.")
            if get_deputy(conn, d["id"]) is not None:
                update_deputy(conn, d["id"], d)
            else:
                insert_deputy(conn, d)
            seen_norms[norm] = d["id"]
        except HTTPException as exc:
            raise _indexed_error(i, exc)
    return len(records)


def _bulk_backups(conn: sqlite3.Connection, records: List[Any]) -> int:
    for i, rec in enumerate(records):
        try:
            d = normalize_backup(rec)
            insert_backup(conn, d)
        except HTTPException as exc:
            raise _indexed_error(i, exc)
    return len(records)


_BULK_HANDLERS: Dict[str, Callable[[sqlite3.Connection, List[Any]], int]] = {
    "contracts": _bulk_contracts,
    "contractors": _bulk_contractors,
    "deputies": _bulk_deputies,
    "backups": _bulk_backups,
}


@router.post("/bulk/{store}")
def bulk_upsert(store: str, records: List[Any] = Body(...)):
    """درج/به‌روزرسانی گروهی در یک تراکنش واحد؛ اگر یک رکورد نامعتبر باشد کل درخواست 422 می‌شود."""
    handler = _BULK_HANDLERS.get(store)
    if handler is None:
        raise HTTPException(status_code=404, detail="مجموعه داده نامعتبر است.")
    with db_session() as conn:
        count = handler(conn, records)
    return {"inserted": count}


# ---------- DELETE /api/data/clear/{store} ----------

_CLEAR_TABLES = {
    "contracts": "contracts",
    "contractors": "contractors",
    "deputies": "deputies",
    "backups": "backup_history",
}


@router.delete("/clear/{store}")
def clear_store(store: str):
    """پاک‌سازی یک مجموعه (بدون settings)."""
    table = _CLEAR_TABLES.get(store)
    if table is None:
        raise HTTPException(status_code=404, detail="مجموعه داده نامعتبر است.")
    with db_session() as conn:
        try:
            cur = conn.execute("DELETE FROM {}".format(table))  # نام جدول از whitelist
        except sqlite3.IntegrityError:
            raise HTTPException(
                status_code=409,
                detail="به دلیل وابستگی قراردادها، پاک‌سازی امکان‌پذیر نیست؛ ابتدا قراردادها را حذف کنید.",
            )
        count = cur.rowcount
    return {"cleared": count}


# ---------- POST /api/data/replace-all و POST /api/migration/import ----------

def _normalize_list(
    items: Any,
    fn: Callable[..., Dict[str, Any]],
    **kwargs: Any,
) -> List[Dict[str, Any]]:
    """اعتبارسنجی لیست رکوردها با ایندکس خطا."""
    if not isinstance(items, list):
        raise HTTPException(status_code=422, detail="ساختار داده ارسالی معتبر نیست.")
    out: List[Dict[str, Any]] = []
    for i, rec in enumerate(items):
        try:
            out.append(fn(rec, **kwargs))
        except HTTPException as exc:
            raise _indexed_error(i, exc)
    return out


def _check_unique_norm(items: List[Dict[str, Any]], key: str, msg: str) -> None:
    """یکتایی درون فایل ورودی (مثلاً دو پیمانکار با نام یکسان)."""
    seen: Dict[str, str] = {}
    for i, d in enumerate(items):
        norm = norm_text(d[key])
        owner = seen.get(norm)
        if owner is not None and owner != d["id"]:
            raise HTTPException(status_code=422, detail="رکورد شماره {} معتبر نیست: {}".format(i + 1, msg))
        seen[norm] = d["id"]


def _check_unique_ids(items: List[Dict[str, Any]]) -> None:
    """id تکراری درون فایل ورودی مجاز نیست."""
    seen: set = set()
    for i, d in enumerate(items):
        if d["id"] in seen:
            raise HTTPException(
                status_code=422,
                detail="رکورد شماره {} معتبر نیست: شناسه رکورد تکراری است.".format(i + 1),
            )
        seen.add(d["id"])


def _replace_all(data: Any, with_settings: bool) -> Dict[str, Any]:
    """پاک‌سازی و درج اتمیک سه جدول اصلی (+ تنظیمات در حالت مهاجرت)."""
    if not isinstance(data, dict) or not any(
        k in data for k in ("contracts", "contractors", "deputies")
    ):
        raise HTTPException(status_code=422, detail="ساختار داده ارسالی معتبر نیست.")

    # اعتبارسنجی کامل قبل از هر تغییری در دیتابیس
    contractor_ds = _normalize_list(data.get("contractors", []), normalize_contractor)
    deputy_ds = _normalize_list(data.get("deputies", []), normalize_deputy)
    contractor_ids = {d["id"] for d in contractor_ds}
    deputy_ids = {d["id"] for d in deputy_ds}
    contract_ds = _normalize_list(
        data.get("contracts", []),
        normalize_contract,
        contractor_ids=contractor_ids,
        deputy_ids=deputy_ids,
    )
    # یکتایی درون فایل (نام/شماره و id)
    _check_unique_norm(contractor_ds, "name", "پیمانکاری با این نام قبلاً ثبت شده است.")
    _check_unique_norm(deputy_ds, "name", "معاونتی با این نام قبلاً ثبت شده است.")
    _check_unique_norm(contract_ds, "contractNumber", "این شماره قرارداد قبلاً ثبت شده است.")
    _check_unique_ids(contractor_ds)
    _check_unique_ids(deputy_ds)
    _check_unique_ids(contract_ds)

    # ذخیره تنظیمات (فقط در مهاجرت؛ اگر نامعتبر بود نادیده گرفته می‌شود)
    settings_saved = False
    if with_settings and isinstance(data.get("settings"), dict):
        try:
            with db_session() as conn:
                srow = conn.execute("SELECT * FROM settings WHERE id = 'app'").fetchone()
                current = row_to_settings(srow) if srow is not None else default_settings()
            sd = normalize_settings(data["settings"], current)
            with db_session() as conn:
                save_settings(conn, sd)
            settings_saved = True
        except HTTPException:
            settings_saved = False

    # جایگزینی اتمیک: خطا در هر نقطه → rollback کامل (در db_session)
    with db_session() as conn:
        try:
            # ترتیب حذف: ابتدا قراردادها (وابسته)، سپس دو جدول دیگر
            conn.execute("DELETE FROM contracts")
            conn.execute("DELETE FROM contractors")
            conn.execute("DELETE FROM deputies")
            # ترتیب درج: ابتدا والد‌ها (پیمانکار/معاونت) سپس قراردادها
            for d in contractor_ds:
                insert_contractor(conn, d)
            for d in deputy_ds:
                insert_deputy(conn, d)
            for d in contract_ds:
                insert_contract(conn, d)
        except HTTPException as exc:
            raise HTTPException(status_code=422, detail="درج رکوردها ناموفق بود: {}".format(exc.detail))

    result: Dict[str, Any] = {
        "contracts": len(contract_ds),
        "contractors": len(contractor_ds),
        "deputies": len(deputy_ds),
    }
    if with_settings:
        result["settingsSaved"] = settings_saved
    return result


@router.post("/replace-all")
def replace_all(data: Dict[str, Any] = Body(...)):
    """Restore کلاینت: جایگزینی کامل قراردادها/پیمانکاران/معاونت‌ها در یک تراکنش."""
    return _replace_all(data, with_settings=False)


@migration_router.post("/import")
def migration_import(data: Dict[str, Any] = Body(...)):
    """مهاجرت IndexedDB → SQLite: داده‌ها + تنظیمات."""
    return _replace_all(data, with_settings=True)
