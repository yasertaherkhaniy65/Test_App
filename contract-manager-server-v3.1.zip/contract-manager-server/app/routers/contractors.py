"""CRUD پیمانکاران — /api/contractors (ورودی/خروجی camelCase)."""
import sqlite3
from typing import Any, Dict, Optional

from fastapi import APIRouter, Body, HTTPException, Response

from app.database import db_session
from app.models import normalize_contractor, req_str, row_to_contractor
from app.utils import norm_text

router = APIRouter(prefix="/api/contractors", tags=["Contractors"])


# ---------- کمک‌تابع‌های مشترک ----------

def get_contractor(conn: sqlite3.Connection, cid: str) -> Optional[Dict[str, Any]]:
    row = conn.execute("SELECT * FROM contractors WHERE id = ?", (cid,)).fetchone()
    return row_to_contractor(row) if row is not None else None


def name_owner(conn: sqlite3.Connection, norm: str, exclude_id: Optional[str] = None) -> Optional[str]:
    """مالک فعلی نام نرمال‌شده (به‌جز رکورد خود فرد)."""
    if exclude_id is None:
        row = conn.execute("SELECT id FROM contractors WHERE name_norm = ?", (norm,)).fetchone()
    else:
        row = conn.execute(
            "SELECT id FROM contractors WHERE name_norm = ? AND id <> ?", (norm, exclude_id)
        ).fetchone()
    return row["id"] if row is not None else None


def insert_contractor(conn: sqlite3.Connection, d: Dict[str, Any]) -> Dict[str, Any]:
    try:
        conn.execute(
            "INSERT INTO contractors (id, name, name_norm, type, grade, mobile, address, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (
                d["id"], d["name"], norm_text(d["name"]), d["type"], d["grade"],
                d["mobile"], d["address"], d["createdAt"],
            ),
        )
    except sqlite3.IntegrityError:
        raise HTTPException(status_code=409, detail="پیمانکاری با این نام قبلاً ثبت شده است.")
    return get_contractor(conn, d["id"])


def update_contractor(conn: sqlite3.Connection, cid: str, d: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    try:
        cur = conn.execute(
            "UPDATE contractors SET name = ?, name_norm = ?, type = ?, grade = ?, mobile = ?, "
            "address = ?, created_at = ? WHERE id = ?",
            (
                d["name"], norm_text(d["name"]), d["type"], d["grade"], d["mobile"],
                d["address"], d["createdAt"], cid,
            ),
        )
    except sqlite3.IntegrityError:
        raise HTTPException(status_code=409, detail="پیمانکاری با این نام قبلاً ثبت شده است.")
    if cur.rowcount == 0:
        return None
    return get_contractor(conn, cid)


# ---------- Endpointها ----------

@router.get("")
def list_contractors():
    """لیست پیمانکاران — مرتب‌سازی فارسی با کلید نرمال‌شده."""
    with db_session() as conn:
        rows = conn.execute("SELECT * FROM contractors").fetchall()
    items = [row_to_contractor(r) for r in rows]
    items.sort(key=lambda c: norm_text(c["name"]))
    return items


@router.post("", status_code=201)
def create_contractor(data: Dict[str, Any] = Body(...)):
    name = req_str(data.get("name"), "نام پیمانکار الزامی است.")
    with db_session() as conn:
        if name_owner(conn, norm_text(name)) is not None:
            raise HTTPException(status_code=409, detail="پیمانکاری با این نام قبلاً ثبت شده است.")
        d = normalize_contractor(data)
        saved = insert_contractor(conn, d)
    return saved


@router.put("/{contractor_id}")
def update_contractor_endpoint(contractor_id: str, data: Dict[str, Any] = Body(...)):
    name = req_str(data.get("name"), "نام پیمانکار الزامی است.")
    with db_session() as conn:
        existing = get_contractor(conn, contractor_id)
        if existing is None:
            raise HTTPException(status_code=404, detail="پیمانکار یافت نشد.")
        # یکتایی نام به‌جز خود رکورد
        if name_owner(conn, norm_text(name), exclude_id=contractor_id) is not None:
            raise HTTPException(status_code=409, detail="پیمانکاری با این نام قبلاً ثبت شده است.")
        d = normalize_contractor(data)
        d["createdAt"] = existing["createdAt"]  # زمان ایجاد اصلی حفظ می‌شود
        updated = update_contractor(conn, contractor_id, d)
    return updated


@router.delete("/{contractor_id}", status_code=204)
def delete_contractor(contractor_id: str):
    with db_session() as conn:
        if get_contractor(conn, contractor_id) is None:
            raise HTTPException(status_code=404, detail="پیمانکار یافت نشد.")
        # چک صریح استفاده در قراردادها (پیام بهتر از خطای FK)
        used = conn.execute(
            "SELECT 1 FROM contracts WHERE contractor_id = ? LIMIT 1", (contractor_id,)
        ).fetchone()
        if used is not None:
            raise HTTPException(status_code=409, detail="این پیمانکار در قراردادها استفاده شده و قابل حذف نیست.")
        try:
            conn.execute("DELETE FROM contractors WHERE id = ?", (contractor_id,))
        except sqlite3.IntegrityError:
            # دفاع دوم (FK RESTRICT)
            raise HTTPException(status_code=409, detail="این پیمانکار در قراردادها استفاده شده و قابل حذف نیست.")
    return Response(status_code=204)
